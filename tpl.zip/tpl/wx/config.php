<?php
    define('APP_ID', 'wxda8d3d9c0cf656b5');
    define('APP_SECRET', '580a19a6302e68e42a358910e9d7674a');
    define('DATA_PATH', './data/');
    /*
     * Environment
     */
    define('ENV', 'sae');
    //define('ENV', 'dev');
    define('SAE_DATA_PATH', 'saekv://');