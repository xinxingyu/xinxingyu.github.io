/**
 * @desc 微信分享接口，前端示例
 */
$(function(){
    var WX_SIGNATURE_API = '../wx/api.php';

    var bootstrap = function () {
        $.ajax({
            url: WX_SIGNATURE_API,
            data: {
                url: location.href.split('#')[0],
                type: "signature"
            },
            dataType: "json"
       })
        .success(function(result) {
            if (result.code != 0) {
                alert('获取签名出错');
                return;
            }
            configWeixin(result.data);
        });
    };

    var setupWeixinShare = function (message) {
            wx.onMenuShareTimeline(message);
            wx.onMenuShareAppMessage(message);
            wx.onMenuShareQQ(message);
            wx.onMenuShareWeibo(message);
            wx.onMenuShareQZone(message);
    };

    var configWeixin = function (options) {
        wx.config({
            debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: options.appId, // 必填，公众号的唯一标识
            timestamp: options.timestamp, // 必填，生成签名的时间戳
            nonceStr: options.nonceStr, // 必填，生成签名的随机串
            signature: options.signature,// 必填，签名，见附录1
            jsApiList: [
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'onMenuShareQQ',
                'onMenuShareWeibo',
                'onMenuShareQZone'
            ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        });
    };

    wx.ready(function () {
        setupWeixinShare({
            title: '测试用的标题', // 分享标题
            desc: '这是一个测试分享信息', // 分享描述
            link: 'http://www.oldteaman.com', // 分享链接
            imgUrl: 'http://www.oldteaman.com/asset/BD0940B4-4B18-4205-9049-BEF1BC8E9452/1.0.7/img/1443287030.logo_h80.png', // 分享图标
            type: '', // 分享类型,music、video或link，不填默认为link
            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
            success: function () {
                // 用户确认分享后执行的回调函数
            },
            cancel: function () {
                // 用户取消分享后执行的回调函数
            }
        });
    });

    bootstrap();
})
